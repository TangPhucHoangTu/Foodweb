import { useEffect, useState } from "react";
import Api, { endpoints } from "../configs/Api";
import MySpinner from "../layout/MySpinner";
import { Button, Card, Col, Row } from "react-bootstrap";
import { useSearchParams } from "react-router-dom";

const Home =() =>{
    
    const [stores,setStores]=useState(null);
    const[q]=useSearchParams();

    useEffect(() =>{
        const loadStores = async () =>{
            try{
            let e=endpoints['stores'];

            let kw=q.get("kw");
            if(kw !==null)
            e=`${e}?kw=${kw}`;
            let res= await Api.get(e);
            setStores(res.data);
            }catch(ex){
                console.error(ex);
            }
        }
        loadStores();
    },[q]);

    if(stores===null)
         return <MySpinner />

    return(
        <>
        <h1 className="text-center text-info">Trang chủ</h1>
       <Row>
        
        {stores.map(s =>{
            return <Col xs={14} md={4} className="mt-2"><Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src={s.imgfoodstore} />
            <Card.Body>
              <Card.Title>{s.name}</Card.Title>
              <Card.Text>{s.location}</Card.Text>
              <Button variant="success">Xem</Button>
            </Card.Body>
          </Card>

          </Col>
        })}
       </Row>
        </>
    )
}

export default Home