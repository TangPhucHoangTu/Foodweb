
import { useRef, useState } from "react";
import { Alert, Button, Form } from "react-bootstrap";
import Api, { endpoints } from "../configs/Api";
import { useNavigate } from "react-router-dom";
import MySpinner from "../layout/MySpinner";

const Register =() =>{
    const [user,setUser] =useState({"username": "","password":"","firstName":"","lastName":"","confirmPassword":"","email":"","phone":""});
    const avatar =useRef();
    const [err,setErr]=useState(null);
    const[loading,setLoading]=useState(false);
    const nav=useNavigate();

    const register=(evt) =>{
        evt.preventDefault();

        const process =async() =>{
            Api.post(endpoints['register'])

            let form=new FormData();
            for (let field in user)
                 if(field!=="confirmPassword")
                     form.append(field,user[field]);

            form.append("avatar",avatar.current.files[0]);

            setLoading(true)
            let res=await Api.post(endpoints['register'],form);
            if(res.status === 201){
            nav("/login");
        }else
        setErr("Lỗi hệ thống");
    }
        if(user.password===user.confirmPassword)
        process();
        else {
            setErr("Mật khẩu không khớp");
        }
        
    }
    const change=(evt,field) =>{
        setUser({...user,[field]:evt.target.value})
        setUser(curent =>{
            return{...curent,[field]:evt.target.value}
        })
    }
    
    return <>
    <h1 className="text-center text-info mt-2" >Đăng ký</h1>
    {err===null?"" :<Alert variant="danger">{err}</Alert>}

    <Form onSubmit={register}>

     
      <Form.Group className="mb-3" >
        <Form.Label>First Name</Form.Label>
        <Form.Control type="text" onChange={e=>change(e,"firstName")} placeholder="First Name" required/>
      </Form.Group>
      <Form.Group className="mb-3" >
        <Form.Label>Last Name</Form.Label>
        <Form.Control  type="text" onChange={e=>change(e,"lastName")}  placeholder="Last Name"  required/>
      </Form.Group>
      <Form.Group className="mb-3" >
        <Form.Label>Tên đăng nhập</Form.Label>
        <Form.Control value={user.username} onChange={e=>change(e,"username")} type="text" placeholder="Tên đăng nhập" />
      </Form.Group>
      <Form.Group className="mb-3" >
        <Form.Label>Mật khẩu</Form.Label>
        <Form.Control value={user.password} onChange={e=>change(e,"password")} type="password" placeholder="Mật khẩu" required/>
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>Confirm Password</Form.Label>
        <Form.Control value={user.confirmPassword} onChange={e=>setUser({...user,"confirmPassword":e.target.value})} type="password" placeholder="ConfirmPassword" />
      </Form.Group>
      <Form.Group className="mb-3" >
        <Form.Label>Email</Form.Label>
        <Form.Control  type="email"onChange={e=>change(e,"email")} placeholder="Email" required/>
      </Form.Group>
      <Form.Group className="mb-3" >
        <Form.Label>Phone</Form.Label>
        <Form.Control  type="text"onChange={e=>change(e,"phone")}  placeholder="Phone" />
      </Form.Group>
      <Form.Group className="mb-3" >
        <Form.Label>Ảnh đại diện</Form.Label>
        <Form.Control  type="file" ref={avatar} />
      </Form.Group>
      <Form.Group className="mb-3">
        {loading===true?<MySpinner/>: <Button variant="info" type="submit">Đăng ký</Button>}
      </Form.Group>
      </Form>
    </>
    
}
export default Register