import { useContext, useEffect, useState } from "react";
import MySpinner from "../layout/MySpinner";
import Api, { endpoints } from "../configs/Api";
import { MyUserContext } from "../App";
import { useParams } from "react-router-dom";
import { Col, Image, Row } from "react-bootstrap";

const FoodsDetail = () => {
    const [user, ] = useContext(MyUserContext);
    const {foodId} = useParams();
    const [foods, setFoods] = useState(null);

    useEffect(() => {
        const loadFoods = async () => {
            let {data} = await Api.get(endpoints['details'](foodId));
            setFoods(data); 
        }
        

        loadFoods();
       
    }, []);
    if (foods === null)
    return <MySpinner/>;
    let url = `/login?next=/foods/${foodId}`;

    return <>
        <h1 className="text-center text-info mt-2">CHI TIẾT SẢN PHẨM ({foodId})</h1>
        <Row>
            <Col md={5} xs={6}>
                <Image src={foods.image} rounded fluid />
            </Col>
            <Col md={5} xs={6}>
                <h2 className="text-danger">{foods.name}</h2>
                <h3>{foods.price} VNĐ</h3>
            </Col>
        </Row>
        <hr />  
        </>
}
export default FoodsDetail;