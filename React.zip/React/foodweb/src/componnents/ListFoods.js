import { useContext, useEffect, useState } from "react";
import { Button, Card, Col, Row } from "react-bootstrap";
import { Link, useSearchParams } from "react-router-dom";
import Api, { endpoints } from "../configs/Api";
import MySpinner from "../layout/MySpinner";
import { MyCartContext } from "../App";
import cookie from "react-cookies"

const ListFoods =() =>{
    const[,cartDispatch]=useContext(MyCartContext);
    const [foods,setFoods]=useState(null);
    const[k]=useSearchParams();

    useEffect(() =>{
        const loadFoods = async () =>{
            try{
            let e=endpoints['foods'];

            let kw=k.get("kw");
            if(kw !==null)
            e=`${e}?kw=${kw}`;
            let res= await Api.get(e);
            setFoods(res.data);
            }catch(ex){
                console.error(ex);
            }
        }
        loadFoods();
    },[k]);
    const order =(foods)=>{
        cartDispatch({
            "type":"inc",
            "payload":1
        });

        let cart=cookie.load("cart") ||null;
        if(cart==null)
            cart={};
        if(foods.foodId in cart){
            cart[foods.foodId]["quantity"]+=1;

        }else{
            cart[foods.foodId]={
                "id": foods.foodId,
                "name":foods.name,
                "quantity":1,
                "unitPrice":foods.price
            }
        }
        cookie.save("cart",cart);
        console.info(cart);
    }

    if(foods===null)
         return <MySpinner />

    return(
        <>
        <h1 className="text-center text-info">Danh sách món ăn</h1>
       <Row>
        
        {foods.map(f =>{
             let url = `/foods/${f.id}`;
            return <Col xs={14} md={4} className="mt-2"><Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src={f.imgfood} />
            <Card.Body>
              <Card.Title>{f.name}</Card.Title>
              <Card.Text>{f.price} VND</Card.Text>
              <Button variant="success" onClick={()=>order(f)}>Đặt món</Button>
              <Link to={url} className="btn btn-info" style={{marginRight: "5px"}} variant="primary">Xem chi tiết</Link>
            </Card.Body>
          </Card>

          </Col>
        })}
       </Row>
        </>
    )
}
export default ListFoods;