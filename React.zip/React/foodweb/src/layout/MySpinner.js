import { Spinner } from "react-bootstrap";

const MySpinner =() =>{
    return <Spinner animation="grow" variant="info"/>;
}
export default MySpinner;
