import { useContext, useState } from "react";
import { Badge, Button, Col, Container, Form, Nav,  Navbar, Row } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { MyCartContext, MyUserContext } from "../App";


const Header =() =>{
  const[user,dispatch]=useContext(MyUserContext);
  const[cartCounter]=useContext(MyCartContext);
  const[kw,setKw]=useState("");
  const nav=useNavigate();
  const search=(evt) =>{
evt.preventDefault();
nav(`/?kw=${kw}`)

}
const logout=() =>{
  dispatch({
    "type":"logout"
  })
  }
    return (
        <>
         <Navbar bg="dark" data-bs-theme="dark">
        <Container>
          <Navbar.Brand href="#home">FoodWeb</Navbar.Brand>
          <Nav className="me-auto">
            <Link className="nav-link " to="/">Trang chủ</Link>
            <Link className="nav-link " to="/liststores">Cửa hàng</Link>
            <Link className="nav-link " to="/listfoods">Món ăn</Link>
            <Link className="nav-link " to="#">Bình luận</Link>
          
            {user===null ?<>
              <Link className="nav-link " to="/login">Đăng nhập</Link>
              <Link className="nav-link " to="/register">Đăng ký</Link>
            </>:<>
            <Link className="nav-link text-info" to="/">Hello  {user.username}</Link>
            <Button variant="info" onClick={logout}>Đăng xuất</Button>
            </>}
            <Link className="nav-link text-danger" to="/cart">&#128722;<Badge bg="danger">{cartCounter}</Badge></Link>
          
          </Nav>
          <Form onSubmit={search}inline>
        <Row>
          <Col xs="auto">
            <Form.Control
              type="text"
              value={kw}
              onChange={e => setKw(e.target.value)}
              placeholder="Nhập từ khóa" name="kw"
              className=" mr-sm-2"
            />
          </Col>
          <Col xs="auto">
            <Button type="submit">Tìm</Button>
          </Col>
        </Row>
      </Form>
        </Container>
        
      </Navbar>
      <br />
        </>
        
    )
}

export default Header;