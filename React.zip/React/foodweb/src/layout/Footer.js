import { Alert } from "react-bootstrap";

const Footer =() =>{
    return (
    <>
        <Alert variant="info" className="mt-2">
           FoodWeb &copy; 2023
            </Alert>
    </>
       
    )
}

export default Footer;