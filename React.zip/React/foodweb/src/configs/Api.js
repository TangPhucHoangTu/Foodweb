import axios from "axios";
import cookie from "react-cookies";

const SERVER_CONTEXT="/DiaDiemAnUong";
const SERVER="http://localhost:8080/";

export const endpoints={
    "stores" :`${SERVER_CONTEXT}/api/stores/`,
    "foods":`${SERVER_CONTEXT}/api/foods/`,
    "login":`${SERVER_CONTEXT}/api/login/`,
    "current-user":`${SERVER_CONTEXT}/api/current-user/`,
    "register": `${SERVER_CONTEXT}/api/users/`,
    "details": (foodId) => `${SERVER_CONTEXT}/api/foods/${foodId}/`

}
export const authApi=() =>{
    return axios.create({
        baseURL:SERVER,
        headers:{
            "Authorization": cookie.load("token")
        }
    })
}

export default axios.create({
    baseURL:SERVER
})